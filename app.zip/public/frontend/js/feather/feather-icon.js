 /**=====================
     Feather Icon js
==========================**/
 feather.replace()