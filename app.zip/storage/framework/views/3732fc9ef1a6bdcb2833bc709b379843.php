<ul class="sidebar-links pt-5" id="simple-bar">
    <li class="back-btn"></li>
    <li class="sidebar-list">
      <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(route('dashboard')); ?>">
        <i class="ri-home-line"></i>
        <span>Dashboard</span>
      </a>
    </li>
    <li class="sidebar-list">
      <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(route('product.index')); ?>">
        <i class="ri-store-3-line"></i>
        <span>Product</span>
      </a>
    </li>
    <li class="sidebar-list">
        <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(route('inventory.index')); ?>">
          <i class="ri-archive-line"></i>
          <span>Stok Barang</span>
        </a>
      </li>
    <li class="sidebar-list d-none">
      <a class="sidebar-link sidebar-title link-nav" href="javascript:void(0)">
      <i class="ri-user-3-line"></i>
      <span>Users</span>
      </a>
    </li>
    <li class="sidebar-list">
      <a class="sidebar-link sidebar-title link-nav" href="<?php echo e(route('transaction.index')); ?>">
      <i class="ri-exchange-dollar-line"></i>
      <span>Transaksi</span>
      </a>
    </li>
    <li class="sidebar-list d-none">
      <a class="sidebar-link sidebar-title link-nav" href="javascript:void(0)">
      <i class="ri-settings-line"></i>
      <span>Settings</span>
      </a>
    </li>
  </ul>
<?php /**PATH C:\laragon\www\pos\resources\views/sidebars/backend.blade.php ENDPATH**/ ?>