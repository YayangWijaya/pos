<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <div class="card card-table">
            <div class="card-body">
                <div class="title-header option-title d-sm-flex d-block">
                    <h5>Data Produk</h5>
                    <div class="right-options">
                        <ul class="d-flex align-items-center">
                            <li>
                                <form method="GET" action="<?php echo e(route('product.index')); ?>" class="top-nav-search table-search-blk">
                                    <input type="text" class="form-control" placeholder="Cari produk" name="keyword" value="<?php echo e(request()->get('keyword')); ?>">
                                    <span class="btn search"><img src="assets/img/icons/search-normal.svg" alt></span>
                                </form>
                            </li>
                            <li>
                                <a class="btn btn-solid" href="<?php echo e(route('product.create')); ?>">Tambah Produk</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div>
                    <div class="table-responsive">
                        <table class="table all-package theme-table table-product" id="table_id">
                            <thead>
                                <tr>
                                    <th>Product Image</th>
                                    <th>Product Name</th>
                                    <th>Stok Barang</th>
                                    <th>Price</th>
                                    <th>Option</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <div class="table-image">
                                            <img src="<?php echo e(asset($product->image_link)); ?>" class="img-fluid" alt="<?php echo e($product->name); ?>">
                                        </div>
                                    </td>

                                    <td><?php echo e($product->name); ?></td>

                                    <td><?php echo e($product->quantity); ?></td>

                                    <td class="td-price"><?php echo e($product->price_formatted); ?></td>

                                    <td>
                                        <ul>
                                            <li>
                                                <a href="<?php echo e(route('product.edit', ['product' => $product->id])); ?>">
                                                    <i class="ri-pencil-line"></i>
                                                </a>
                                            </li>

                                            <li>
                                                <a href="#" onClick="deleteProduct(<?php echo e($product->id); ?>)">
                                                    <i class="ri-delete-bin-line"></i>
                                                </a>

                                                <form action="<?php echo e(route('product.destroy', ['product' => $product->id])); ?>" method="POST" id="delete-<?php echo e($product->id); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                </form>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5">No Data</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function deleteProduct(id) {
    Swal.fire({
        title: 'Hapus produk?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Hapus',
    }).then((result) => {
        if (result.isConfirmed) {
            $(`#delete-${id}`).submit();
        }
    })
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nanda\resources\views/backend/product/index.blade.php ENDPATH**/ ?>