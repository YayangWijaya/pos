<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <div class="card card-table">
            <div class="card-body">
                <div class="title-header option-title d-sm-flex d-block">
                    <h5>Stok Barang</h5>
                    <div class="right-options">
                        <ul>
                            <li>
                                <a class="btn btn-solid" href="<?php echo e(route('inventory.create')); ?>">Tambah Stok</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div>
                    <div class="table-responsive">
                        <table class="table all-package theme-table table-product" id="table_id">
                            <thead>
                                <tr>
                                    <th>Gambar</th>
                                    <th>Nama Produk</th>
                                    <th>Kuantitas</th>
                                    <th>Purchase Price</th>
                                    <th>Perubahaan Kuantitas</th>
                                    <th>Kuantitas Tersedia</th>
                                    <th>Dibuat</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <div class="table-image">
                                            <img src="<?php echo e(asset($inventory->product->image_link)); ?>" class="img-fluid" alt="<?php echo e($inventory->product->name); ?>">
                                        </div>
                                    </td>

                                    <td><?php echo e($inventory->product->name); ?></td>

                                    <td><?php echo e($inventory->quantity); ?></td>

                                    <td class="td-price"><?php echo e($inventory->purchase_price_formatted); ?></td>

                                    <td><?php echo e($inventory->quantity_changes); ?></td>

                                    <td><?php echo e($inventory->current_quantity); ?></td>

                                    <td><?php echo e(date('d-M-Y H:i', strtotime($inventory->created_at))); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6">No Data</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nanda\resources\views/backend/inventory/index.blade.php ENDPATH**/ ?>