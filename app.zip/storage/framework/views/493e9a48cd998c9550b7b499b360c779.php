<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <form class="row" method="post" action="<?php echo e(route('product.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="col-sm-8 m-auto">
                <div class="card">
                    <div class="card-body">
                        <div class="card-header-2">
                            <h5>Product Information</h5>
                        </div>

                        <div class="theme-form theme-form-2 mega-form">
                            <div class="mb-4 row align-items-center">
                                <label class="form-label-title col-sm-3 mb-0">Product Name</label>
                                <div class="col-sm-9">
                                    <input class="form-control alpha-only" name="name" type="text" placeholder="Product Name" required>
                                </div>
                            </div>

                            

                            <div class="mb-4 row align-items-center">
                                <label class="col-sm-3 col-form-label form-label-title">Unit</label>
                                <div class="col-sm-9">
                                    <select class="w-100" name="unit" required>
                                        <option disabled>Unit Menu</option>
                                        <option value="Pieces">Pieces</option>
                                        <option value="Kilogram">Kilogram</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-4 row align-items-center">
                                <label class="col-sm-3 form-label-title">Price</label>
                                <div class="col-sm-9">
                                    <input class="form-control" name="price" type="number" placeholder="0" required>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        <div class="card-header-2">
                            <h5>Product Images</h5>
                        </div>

                        <div class="theme-form theme-form-2 mega-form">
                            <div class="mb-4 row align-items-center">
                                <label class="col-sm-3 col-form-label form-label-title">Image</label>
                                <div class="col-sm-9">
                                    <input class="form-control form-choose" name="image" id="image" type="file" required>
                                </div>
                            </div>

                            <div class="mb-4 row">
                                <div class="col-sm-9 offset-sm-3" id="preview-image"></div>
                                <div class="col-sm-9 offset-sm-3 d-flex justify-content-center mt-2">
                                    <button type="button" class="btn btn-sm btn-secondary d-none" id="remove-image">HAPUS GAMBAR</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-center mb-4">
                    <button type="submit" class="btn btn-primary">Add Product</a>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    var previewElement = document.getElementById('preview-image');
    var removeBtn = document.getElementById('remove-image');
    var fileInput = document.getElementById('image');

    fileInput.addEventListener('change', function(event) {
        var file = event.target.files[0];

        if (file) {
            var reader = new FileReader();
            reader.addEventListener('load', function(e) {
                var imgElement = document.createElement('img');
                imgElement.src = e.target.result;
                imgElement.classList.add('w-100');
                imgElement.classList.add('rounded');

                previewElement.innerHTML = '';

                previewElement.appendChild(imgElement);
                removeBtn.classList.remove('d-none');
            });

            reader.readAsDataURL(file);
        }
    });

    removeBtn.addEventListener('click', function(event) {
        previewElement.innerHTML = '';
        removeBtn.classList.add('d-none');
        fileInput.value = '';
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pos\resources\views/backend/product/create.blade.php ENDPATH**/ ?>