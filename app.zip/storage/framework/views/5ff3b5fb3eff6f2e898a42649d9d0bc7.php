<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <form method="get" action="<?php echo e(route('dashboard')); ?>" id="filterForm" class="row">
            <div class="col-3 mb-4">
                <select name="month" id="month" class="form-control" onChange="document.getElementById('filterForm').submit()">
                    <option value="all">Semua</option>
                    <?php $__currentLoopData = ['01','02','03','04','05','06','07','08','09','10','11','12']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($month); ?>" <?php echo e(request()->month ? (request()->month === $month ? 'selected' : '') : (date('m') === $month ? 'selected' : '')); ?>><?php echo e(date('F', strtotime("2023-{$month}-01"))); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-3 mb-4">
                <select name="year" id="year" class="form-control" onChange="document.getElementById('filterForm').submit()">
                    <option value="all">Semua</option>
                    <?php $__currentLoopData = ['2023', '2024', '2025']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($year); ?>" <?php echo e(request()->year ? (request()->year === $year ? 'selected' : '') : (date('Y') === $year ? 'selected' : '')); ?>><?php echo e($year); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </form>
    </div>
    <div class="col-sm-6 col-xxl-3 col-lg-6">
        <div class="main-tiles border-5 border-0  card-hover card o-hidden">
            <div class="custome-1-bg b-r-4 card-body">
                <div class="media align-items-center static-top-widget">
                    <div class="media-body p-0">
                        <span class="m-0">Jumlah Pendapatan</span>
                        <h4 class="mb-0 counter">Rp <?php echo e(number_format($revenue, 0, ',', '.')); ?>

                        </h4>
                    </div>
                    <div class="align-self-center text-center">
                        <i class="ri-database-2-line"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-xxl-3 col-lg-6">
        <div class="main-tiles border-5 card-hover border-0 card o-hidden">
            <div class="custome-4-bg b-r-4 card-body">
                <div class="media static-top-widget">
                    <div class="media-body p-0">
                        <span class="m-0">Pendapatan Bersih</span>
                        <h4 class="mb-0 counter">Rp <?php echo e(number_format($net, 0, ',', '.')); ?>

                        </h4>
                    </div>

                    <div class="align-self-center text-center">
                        <i class="ri-user-add-line"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-xxl-3 col-lg-6">
        <div class="main-tiles border-5 card-hover border-0 card o-hidden">
            <div class="custome-2-bg b-r-4 card-body">
                <div class="media static-top-widget">
                    <div class="media-body p-0">
                        <span class="m-0">Jumlah Pesanan</span>
                        <h4 class="mb-0 counter"><?php echo e(number_format($orders, 0, ',', '.')); ?>

                        </h4>
                    </div>
                    <div class="align-self-center text-center">
                        <i class="ri-shopping-bag-3-line"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-xxl-3 col-lg-6">
        <div class="main-tiles border-5 card-hover border-0  card o-hidden">
            <div class="custome-3-bg b-r-4 card-body">
                <div class="media static-top-widget">
                    <div class="media-body p-0">
                        <span class="m-0">Jumlah Produk</span>
                        <h4 class="mb-0 counter"><?php echo e(number_format($products, 0, ',', '.')); ?>

                            <a href="<?php echo e(route('product.create')); ?>" class="badge badge-light-secondary grow">
                                TAMBAH PRODUK</a>
                        </h4>
                    </div>

                    <div class="align-self-center text-center">
                        <i class="ri-chat-3-line"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nanda\resources\views/backend/index.blade.php ENDPATH**/ ?>