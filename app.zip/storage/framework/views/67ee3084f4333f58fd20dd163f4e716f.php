<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <div class="card card-table">
            <div class="card-body">
                <div class="title-header option-title d-sm-flex d-block">
                    <h5>Transaksi</h5>
                    <div class="right-options">
                        <ul>
                            <li>
                                <a type="button" class="btn btn-success" href="<?php echo e(route('export.transaction', ['from' => request()->from, 'to' => request()->to])); ?>">Export</a>
                            </li>
                            <li>
                                <form class="d-flex align-items-center" action="<?php echo e(route('transaction.index')); ?>" method="get">
                                    <input type="date" class="me-2 form-control" name="from" id="from" value="<?php echo e(request()->from ? date('Y-m-d', strtotime(request()->from)) : ""); ?>"/>
                                    <small class="me-2">To</small>
                                    <input type="date" class="me-2 form-control" name="to" id="to" value="<?php echo e(request()->to ? date('Y-m-d', strtotime(request()->to)) : ""); ?>"/>
                                    <button class="btn btn-primary" type="submit">Filter</button>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
                <div>
                    <div class="table-responsive">
                        <table class="table all-package theme-table table-product" id="table_id">
                            <thead>
                                <tr>
                                    <th>Jumlah Beli</th>
                                    <th>Tagihan</th>
                                    <th>Dibayar</th>
                                    <th>Kembalian</th>
                                    <th>Tanggal</th>
                                    <th>Detail</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(count($transaction->items)); ?></td>

                                    <td><?php echo e(number_format($transaction->amount, 0, ',', '.')); ?></td>

                                    <td><?php echo e(number_format($transaction->paid, 0, ',', '.')); ?></td>

                                    <td><?php echo e(number_format($transaction->exchange, 0, ',', '.')); ?></td>

                                    <td><?php echo e(date('d-M-Y H:i', strtotime($transaction->created_at))); ?></td>

                                    <td><a href="<?php echo e(route('transaction.show', ['transaction' => $transaction->id])); ?>">View Detail</a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6">No Data</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pos\resources\views/backend/transaction/index.blade.php ENDPATH**/ ?>