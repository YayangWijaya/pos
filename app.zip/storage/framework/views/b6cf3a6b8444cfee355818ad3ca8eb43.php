<table>
    <thead>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr>
        <th></th>
        <th>Nama Pelanggan</th>
        <th>Jumlah Barang</th>
        <th>Jumlah Pembelian</th>
        <th>Dibayar</th>
        <th>Kembali</th>
        <th>Nama Barang</th>
        <th>Note</th>
        <th>Tanggal</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td></td>
            <td><?php echo e($transaction['customer_name']); ?></td>
            <td><?php echo e(count($transaction['items'])); ?></td>
            <td><?php echo e(number_format($transaction['amount'], 0, ',', '.')); ?></td>
            <td><?php echo e(number_format($transaction['paid'], 0, ',', '.')); ?></td>
            <td><?php echo e(number_format($transaction['exchange'], 0, ',', '.')); ?></td>
            <td>
                <?php
                    $items = [];

                    foreach ($transaction['items'] as $item) {
                        if (!array_key_exists($item['product']['name'], $items)) {
                            $items[$item['product']['name']] = 1;
                        } else {
                            $items[$item['product']['name']]++;
                        }
                    }
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    - <?php echo e($value); ?> x<?php echo e($total); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    -
                <?php endif; ?>
            </td>
            <td><?php echo e($transaction['note']); ?></td>
            <td><?php echo e(date('d-M-Y H:i', strtotime($transaction['created_at']))); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\nanda\resources\views/exports/transaction.blade.php ENDPATH**/ ?>