<table>
    <thead>
    <tr>
        <th>Nama Pelanggan</th>
        <th>Jumlah Barang</th>
        <th>Jumlah Pembelian</th>
        <th>Kembali</th>
        <th>Note</th>
        <th>Tanggal</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($transaction->customer_name); ?></td>
            <td><?php echo e(count($transaction->items)); ?></td>
            <td><?php echo e($transaction->amount); ?></td>
            <td><?php echo e($transaction->exchange); ?></td>
            <td><?php echo e($transaction->note); ?></td>
            <td><?php echo e(date('d-M-Y H:i', strtotime($transaction->created_at))); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\pos\resources\views/exports/transaction.blade.php ENDPATH**/ ?>