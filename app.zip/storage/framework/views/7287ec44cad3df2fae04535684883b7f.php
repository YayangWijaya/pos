<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <h2>User Management</h2>
        <div class="card card-table mt-3">
            <div class="card-body">
                <div class="title-header option-title d-sm-flex d-block">
                    <form method="get" action="<?php echo e(route('user.index')); ?>" class="d-flex">
                        <input type="text" class="form-control me-3" name="keyword" placeholder="Cari user..." value="<?php echo e(request()->keyword); ?>"/>
                        <button type="submit" class="btn theme-bg-color btn-sm text-white fw-bold mend-auto">Cari</button>
                    </form>

                    <div class="right-options">
                        <ul>
                            <li>
                                <a class="btn theme-bg-color btn-sm text-white fw-bold mend-auto" type="button" href="<?php echo e(route('user.create')); ?>">Tambah User</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div>
                    <div class="table-responsive">
                        <table class="table all-package theme-table table-product" id="table_id">
                            <thead>
                                <tr>
                                    <th class="text-start">Nama</th>
                                    <th class="text-start">Alamat Email</th>
                                    <th class="text-start">No HP</th>
                                    <th class="text-start">Role</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-start"><?php echo e($user->name); ?></td>
                                    <td class="text-start"><?php echo e($user->email); ?></td>
                                    <td class="text-start"><?php echo e($user->phone ?: '-'); ?></td>
                                    <td class="text-start"><?php echo e($user->role_name); ?></td>

                                    <td>
                                        <a href="<?php echo e(route('user.edit', ['user' => $user->id])); ?>">
                                            <i class="ri-pencil-line"></i>
                                        </a>

                                        <a href="#" onClick="deleteUser(<?php echo e($user->id); ?>)">
                                            <i class="ri-delete-bin-line"></i>
                                        </a>

                                        <form action="<?php echo e(route('user.destroy', ['user' => $user->id])); ?>" method="POST" id="delete-<?php echo e($user->id); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5">No Data</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script>
function deleteUser(id) {
    Swal.fire({
        title: 'Hapus user?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Hapus',
    }).then((result) => {
        if (result.isConfirmed) {
            $(`#delete-${id}`).submit();
        }
    })
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\nanda\resources\views/backend/user/index.blade.php ENDPATH**/ ?>